//
//  Override_OSX.h
//  Override_OSX
//
//  Created by guzhu on 2020/4/28.
//  Copyright © 2020 fairygui. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Override_OSX.
FOUNDATION_EXPORT double Override_OSXVersionNumber;

//! Project version string for Override_OSX.
FOUNDATION_EXPORT const unsigned char Override_OSXVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Override_OSX/PublicHeader.h>


@interface Override_OSX_Loader : NSObject
@end
